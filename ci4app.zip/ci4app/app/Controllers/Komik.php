<?php 
namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'litle' => 'Daftar Komik'
        ];
        return view ('komik/index', $data);
    }
}
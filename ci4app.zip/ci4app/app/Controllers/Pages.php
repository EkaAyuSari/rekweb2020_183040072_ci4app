<?php namespace App\Controllers;

class Pages extends BaseController
{
	public function index()
	{
        echo view('layout/header');
        echo view('pages/aboout');
        echo view('layout/footer');

	    // return view('welcome_message');
        // echo 'Hello World!';
        echo view view('pages/home');
    } 

    public function about()
    {
        // return view('pages/about');
        echo view('layout/header');
        echo view('pages/aboout');
        echo view('layout/footer');
    }
	//--------------------------------------------------------------------

}

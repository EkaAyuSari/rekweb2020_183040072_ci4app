<?php namespace App\Controllers;

class Pages extends BaseController
{
	public function index()
	{
        $data = [
            'title' => 'Home | WebProgramUnpas',
            'tes' => ['satu', 'dua', 'tiga']
        ];
        
        return view('pages/home', $data);
        
        echo view view('pages/home');
    } 

    public function about()
    {
        // return view('pages/about');
        $data = [
            'title' => 'About Me'
        ];

        return view('pages/aboout', $data);
    }

    public function contact()
    {
        $data = [
            'title' => 'Contact Us'
            'alamat' => [
                [
                   'tipe' => 'rumah',
                   'alamat' =>'Jl. abc No. 123',
                   'kota' => 'Bandung'
                ],
                [
                    'tipe' => 'Kantor'
                    'alamat' => 'Jl. SetiabudiNo.193',
                    'kota' => 'Bandung'
                ]
            ]
        ];

        return view('pages/contact' $data);
    }
	//--------------------------------------------------------------------

}

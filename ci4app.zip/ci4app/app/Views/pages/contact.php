<?= $this->extend('layout/template'); ?>

<div class="container">
<div class="row">
    <div class="col">
        <h2>Contact Us</h2>
        <?php  foreac ($alamat as $a) : ?>
        <ul>
        <li><?= $a['tipe']; ?</li>
        <li><?= $a['alamat']; ?></li>
        <li><?= $a['kota']; ?></li>
        </ul>
    </div>
</div>
</div>
<?= $this->endSection(); ?>